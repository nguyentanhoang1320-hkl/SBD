from django.urls import path
from . import views

urlpatterns = [
    # PUBLIC
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),
    path("search/", views.search, name="search"),
    path("project/", views.project, name="project"),
    path("project/<int:id>/", views.project_detail, name="project_detail"),
    path("product/", views.product_public, name="product"),
    path("product/<int:id>/", views.product_detail, name="product_detail"),
    path("post/", views.post_public, name="post"),
    path("post/<int:id>/", views.post_detail, name="post_detail"),
    path("office-rental/", views.office_rental_public, name="office_rental"),
    path(
        "office-rental/<int:id>/",
        views.office_rental_detail,
        name="office_rental_detail",
    ),
    path(
        "education-space-design/",
        views.education_space_design_public,
        name="education_space_design",
    ),
    path(
        "education-space-design/<int:id>/",
        views.education_space_design_detail,
        name="education_space_design_detail",
    ),
    path(
        "industrial/",
        views.specialized_service_public,
        {"sector": "industrial"},
        name="industrial",
    ),
    path(
        "industrial/<int:id>/",
        views.specialized_service_detail,
        {"sector": "industrial"},
        name="industrial_detail",
    ),
    path(
        "civil/",
        views.specialized_service_public,
        {"sector": "civil"},
        name="civil",
    ),
    path(
        "civil/<int:id>/",
        views.specialized_service_detail,
        {"sector": "civil"},
        name="civil_detail",
    ),
    path(
        "energy-green/",
        views.specialized_service_public,
        {"sector": "energy_green"},
        name="energy_green",
    ),
    path(
        "energy-green/<int:id>/",
        views.specialized_service_detail,
        {"sector": "energy_green"},
        name="energy_green_detail",
    ),
    path(
        "interior-commercial/",
        views.specialized_service_public,
        {"sector": "interior_commercial"},
        name="interior_commercial",
    ),
    path(
        "interior-commercial/<int:id>/",
        views.specialized_service_detail,
        {"sector": "interior_commercial"},
        name="interior_commercial_detail",
    ),
    # AUTH
    path("login/", views.login_view, name="login"),
    path("register/", views.register_view, name="register"),
    path("forgot-password/", views.forgot_password_request, name="forgot_password"),
    path(
        "forgot-password/verify/",
        views.forgot_password_verify,
        name="forgot_password_verify",
    ),
    path(
        "change-password/",
        views.change_password_request,
        name="change_password_request",
    ),
    path(
        "change-password/verify/",
        views.change_password_verify,
        name="change_password_verify",
    ),
    path("logout/", views.logout_view, name="logout"),
    path("system-settings/", views.system_settings, name="system_settings"),
    path(
        "staff-login-activity/",
        views.staff_login_activity,
        name="staff_login_activity",
    ),
    path("staff-map/", views.staff_map, name="staff_map"),
    path("staff-map/snapshot/", views.staff_map_snapshot, name="staff_map_snapshot"),
    path(
        "staff-map/positions/add/",
        views.staff_map_position_create,
        name="staff_map_position_add",
    ),
    path(
        "staff-map/positions/<int:id>/update/",
        views.staff_map_position_update,
        name="staff_map_position_update",
    ),
    path(
        "staff-map/positions/<int:id>/delete/",
        views.staff_map_position_delete,
        name="staff_map_position_delete",
    ),
    # DASHBOARD
    path("dashboard/", views.dashboard, name="dashboard"),
    path("email-otp-settings/", views.email_otp_settings_edit, name="email_otp_settings"),
    path("staff-accounts/", views.staff_account_list, name="staff_account_list"),
    path(
        "staff-accounts/add/",
        views.staff_account_create,
        name="staff_account_add",
    ),
    path(
        "staff-accounts/<int:id>/edit/",
        views.staff_account_update,
        name="staff_account_edit",
    ),
    path(
        "staff-accounts/<int:id>/toggle-status/",
        views.staff_account_toggle_status,
        name="staff_account_toggle_status",
    ),
    # CRUD
    # project
    path("site-logo/", views.system_settings, name="site_logo"),
    path("project/add/", views.project_create, name="project_add"),
    path("project/edit/<int:id>/", views.project_update, name="project_edit"),
    path("project/delete/<int:id>/", views.project_delete, name="project_delete"),
    path(
        "project/featured/",
        views.featured_project_list,
        name="featured_project_list",
    ),
    # product
    path("products/", views.product_list, name="product_list"),
    path("product/add/", views.product_create, name="product_add"),
    path("product/edit/<int:id>/", views.product_update, name="product_edit"),
    path("product/delete/<int:id>/", views.product_delete, name="product_delete"),
    # post
    path("posts/", views.post_list, name="post_list"),
    path("post/add/", views.post_create, name="post_add"),
    path("post/edit/<int:id>/", views.post_update, name="post_edit"),
    path("post/delete/<int:id>/", views.post_delete, name="post_delete"),
    path(
        "office-rentals/",
        views.office_rental_list,
        name="office_rental_list",
    ),
    path("office-rental/add/", views.office_rental_create, name="office_rental_add"),
    path(
        "office-rental/edit/<int:id>/",
        views.office_rental_update,
        name="office_rental_edit",
    ),
    path(
        "office-rental/delete/<int:id>/",
        views.office_rental_delete,
        name="office_rental_delete",
    ),
    path(
        "education-space-designs/",
        views.education_space_design_list,
        name="education_space_design_list",
    ),
    path(
        "education-space-design/add/",
        views.education_space_design_create,
        name="education_space_design_add",
    ),
    path(
        "education-space-design/edit/<int:id>/",
        views.education_space_design_update,
        name="education_space_design_edit",
    ),
    path(
        "education-space-design/delete/<int:id>/",
        views.education_space_design_delete,
        name="education_space_design_delete",
    ),
    path(
        "industrial-services/",
        views.specialized_service_list,
        {"sector": "industrial"},
        name="industrial_list",
    ),
    path(
        "industrial/add/",
        views.specialized_service_create,
        {"sector": "industrial"},
        name="industrial_add",
    ),
    path(
        "industrial/edit/<int:id>/",
        views.specialized_service_update,
        {"sector": "industrial"},
        name="industrial_edit",
    ),
    path(
        "industrial/delete/<int:id>/",
        views.specialized_service_delete,
        {"sector": "industrial"},
        name="industrial_delete",
    ),
    path(
        "civil-services/",
        views.specialized_service_list,
        {"sector": "civil"},
        name="civil_list",
    ),
    path(
        "civil/add/",
        views.specialized_service_create,
        {"sector": "civil"},
        name="civil_add",
    ),
    path(
        "civil/edit/<int:id>/",
        views.specialized_service_update,
        {"sector": "civil"},
        name="civil_edit",
    ),
    path(
        "civil/delete/<int:id>/",
        views.specialized_service_delete,
        {"sector": "civil"},
        name="civil_delete",
    ),
    path(
        "energy-green-services/",
        views.specialized_service_list,
        {"sector": "energy_green"},
        name="energy_green_list",
    ),
    path(
        "energy-green/add/",
        views.specialized_service_create,
        {"sector": "energy_green"},
        name="energy_green_add",
    ),
    path(
        "energy-green/edit/<int:id>/",
        views.specialized_service_update,
        {"sector": "energy_green"},
        name="energy_green_edit",
    ),
    path(
        "energy-green/delete/<int:id>/",
        views.specialized_service_delete,
        {"sector": "energy_green"},
        name="energy_green_delete",
    ),
    path(
        "interior-commercial-services/",
        views.specialized_service_list,
        {"sector": "interior_commercial"},
        name="interior_commercial_list",
    ),
    path(
        "interior-commercial/add/",
        views.specialized_service_create,
        {"sector": "interior_commercial"},
        name="interior_commercial_add",
    ),
    path(
        "interior-commercial/edit/<int:id>/",
        views.specialized_service_update,
        {"sector": "interior_commercial"},
        name="interior_commercial_edit",
    ),
    path(
        "interior-commercial/delete/<int:id>/",
        views.specialized_service_delete,
        {"sector": "interior_commercial"},
        name="interior_commercial_delete",
    ),
    # project category
    path(
        "project-category/", views.project_category_list, name="project_category_list"
    ),
    path(
        "project-category/add/",
        views.project_category_create,
        name="project_category_add",
    ),
    path(
        "project-category/edit/<int:id>/",
        views.project_category_update,
        name="project_category_edit",
    ),
    path(
        "project-category/delete/<int:id>/",
        views.project_category_delete,
        name="project_category_delete",
    ),
    # product category
    path(
        "product-category/", views.product_category_list, name="product_category_list"
    ),
    path(
        "product-category/add/",
        views.product_category_create,
        name="product_category_add",
    ),
    path(
        "product-category/edit/<int:id>/",
        views.product_category_update,
        name="product_category_edit",
    ),
    path(
        "product-category/delete/<int:id>/",
        views.product_category_delete,
        name="product_category_delete",
    ),
    # post category
    path("post-category/", views.post_category_list, name="post_category_list"),
    path("post-category/add/", views.post_category_create, name="post_category_add"),
    path(
        "post-category/edit/<int:id>/",
        views.post_category_update,
        name="post_category_edit",
    ),
    path(
        "post-category/delete/<int:id>/",
        views.post_category_delete,
        name="post_category_delete",
    ),
    # faq
    path("faqs/", views.faq_list, name="faq_list"),
    path("faq/add/", views.faq_create, name="faq_add"),
    path("faq/edit/<int:id>/", views.faq_update, name="faq_edit"),
    path("faq/delete/<int:id>/", views.faq_delete, name="faq_delete"),
    # leadership
    path("leadership/", views.leadership_list, name="leadership_list"),
    path("leadership/add/", views.leadership_create, name="leadership_add"),
    path("leadership/edit/<int:id>/", views.leadership_update, name="leadership_edit"),
    path(
        "leadership/delete/<int:id>/", views.leadership_delete, name="leadership_delete"
    ),
    # about statement types
    path(
        "about-statement-types/",
        views.statement_type_list,
        name="statement_type_list",
    ),
    path(
        "about-statement-types/add/",
        views.statement_type_create,
        name="statement_type_add",
    ),
    path(
        "about-statement-types/edit/<int:id>/",
        views.statement_type_update,
        name="statement_type_edit",
    ),
    path(
        "about-statement-types/delete/<int:id>/",
        views.statement_type_delete,
        name="statement_type_delete",
    ),
    # about statements
    path("about-statements/", views.statement_list, name="statement_list"),
    path("about-statements/add/", views.statement_create, name="statement_add"),
    path(
        "about-statements/edit/<int:id>/", views.statement_update, name="statement_edit"
    ),
    path(
        "about-statements/delete/<int:id>/",
        views.statement_delete,
        name="statement_delete",
    ),
    # certificate
    path("certificates/", views.certificate_list, name="certificate_list"),
    path("certificate/add/", views.certificate_create, name="certificate_add"),
    path(
        "certificate/edit/<int:id>/", views.certificate_update, name="certificate_edit"
    ),
    path(
        "certificate/delete/<int:id>/",
        views.certificate_delete,
        name="certificate_delete",
    ),
    # contact info
    path("contact-infos/", views.contact_info_list, name="contact_info_list"),
    path("contact-info/add/", views.contact_info_create, name="contact_info_add"),
    path(
        "contact-info/edit/<int:pk>/",
        views.contact_info_update,
        name="contact_info_edit",
    ),
    path(
        "contact-info/delete/<int:id>/",
        views.contact_info_delete,
        name="contact_info_delete",
    ),
    path(
        "contact-info/<int:pk>/toggle-status/",
        views.contact_info_toggle_status,
        name="contact_info_toggle_status",
    ),
    path("consultations/", views.consultation_list, name="consultation_list"),
    path(
        "consultations/<int:id>/",
        views.consultation_detail,
        name="consultation_detail",
    ),
    path("notifications/", views.notifications, name="notifications"),
    path(
        "notifications/<int:id>/read/",
        views.notification_read,
        name="notification_read",
    ),
    path(
        "notifications/mark-all-read/",
        views.notification_mark_all_read,
        name="notification_mark_all_read",
    ),
    path("about-intro/", views.about_intro_edit, name="about_intro_edit"),
    path("about-video-tour/", views.about_video_tour_edit, name="about_video_tour_edit"),
    # service types
    path("service-types/", views.service_type_list, name="service_type_list"),
    path("service-types/add/", views.service_type_create, name="service_type_add"),
    path(
        "service-types/edit/<int:id>/",
        views.service_type_update,
        name="service_type_edit",
    ),
    path(
        "service-types/delete/<int:id>/",
        views.service_type_delete,
        name="service_type_delete",
    ),
    # services
    path("services/", views.service_list, name="service_list"),
    path("services/add/", views.service_create, name="service_add"),
    path("services/edit/<int:id>/", views.service_update, name="service_edit"),
    path("services/delete/<int:id>/", views.service_delete, name="service_delete"),
    # Why-choose
    path(
        "why-choose/edit/",
        views.why_choose_section_edit,
        name="why_choose_section_edit",
    ),
    path("why-choose/items/", views.why_choose_item_list, name="why_choose_item_list"),
    path(
        "why-choose/items/add/",
        views.why_choose_item_create,
        name="why_choose_item_add",
    ),
    path(
        "why-choose/items/<int:id>/edit/",
        views.why_choose_item_update,
        name="why_choose_item_edit",
    ),
    path(
        "why-choose/items/<int:id>/delete/",
        views.why_choose_item_delete,
        name="why_choose_item_delete",
    ),
    path('hero/', views.hero_edit, name='hero_edit'),
    path('hero/carousel/delete/<int:id>/', views.hero_carousel_delete, name='hero_carousel_delete'),
    path("partners/", views.partner_list, name="partner_list"),
    path("partner/add/", views.partner_create, name="partner_add"),
    path("partner/edit/<int:id>/", views.partner_update, name="partner_edit"),
    path("partner/delete/<int:id>/", views.partner_delete, name="partner_delete"),
]
